import urllib
from sqlalchemy import create_engine
import pandas as pd

def get_connection():
    """Tạo kết nối đến SQL Server"""
    params = urllib.parse.quote_plus(
        r'DRIVER={SQL Server};'
        r'SERVER=LAPTOP-9UJ2KDO0;'
        r'DATABASE=DW_HotelBooking;'
        r'Trusted_Connection=yes;'
    )
    
    # Tạo engine
    return create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

def run_query(query):
    """Thực thi truy vấn và trả về DataFrame"""
    engine = get_connection()
    return pd.read_sql_query(query, engine)
