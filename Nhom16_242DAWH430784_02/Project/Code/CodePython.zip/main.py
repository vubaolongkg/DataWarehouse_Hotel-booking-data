import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from utils.database import run_query

# Thiết lập trang
st.set_page_config(
    page_title="Dashboard Phân tích Khách sạn",
    page_icon="🏨",
    layout="wide"
)

# Tiêu đề trang
st.title("🏨 Dashboard Phân tích Khách sạn")
st.markdown("---")

# Hiển thị thông tin tổng quan
st.header("Tổng quan")

# Tạo layout 3 cột cho thông tin tổng quan
col1, col2, col3 = st.columns(3)

# Truy vấn tổng doanh thu
total_revenue_query = """
SELECT SUM(Amount) as TotalRevenue FROM Fact_Payment
"""
total_revenue = run_query(total_revenue_query).iloc[0, 0]

# Truy vấn tổng số đặt phòng
total_bookings_query = """
SELECT COUNT(DISTINCT BookingID) as TotalBookings FROM Dim_Booking
"""
total_bookings = run_query(total_bookings_query).iloc[0, 0]

# Truy vấn tổng số khách hàng
total_customers_query = """
SELECT COUNT(DISTINCT CustomerID) as TotalCustomers FROM Dim_Customer
"""
total_customers = run_query(total_customers_query).iloc[0, 0]

# Hiển thị các chỉ số tổng quan
with col1:
    st.metric("Tổng Doanh Thu", f"{total_revenue:,.0f} VND")

with col2:
    st.metric("Tổng Số Đặt Phòng", f"{total_bookings:,}")

with col3:
    st.metric("Tổng Số Khách Hàng", f"{total_customers:,}")

st.markdown("---")

# Hướng dẫn sử dụng
st.header("Hướng dẫn sử dụng")
st.write("""
Chào mừng đến với Dashboard Phân tích Khách sạn. Ứng dụng này cung cấp các phân tích chi tiết về:

- **Phân tích Doanh thu**: Xem doanh thu theo tháng và năm
- **Phân tích Thanh toán & Khách hàng**: Thống kê phương thức thanh toán và top khách hàng
- **Phân tích Dịch vụ**: Chi tiết doanh thu từ các dịch vụ

Sử dụng thanh điều hướng bên trái để chuyển đến các trang phân tích chi tiết.
""")

# Footer
st.markdown("---")
