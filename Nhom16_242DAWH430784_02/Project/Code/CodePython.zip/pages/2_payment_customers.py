import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from utils.database import run_query

# Thiết lập trang
st.set_page_config(
    page_title="Phân tích Thanh toán & Khách hàng",
    page_icon="💳",
    layout="wide"
)

# Tiêu đề trang
st.title("💳 Phân tích Phương thức Thanh toán & Khách hàng")
st.markdown("---")

# Truy vấn phương thức thanh toán
payment_method_query = """
SELECT 
    pm.MethodName,
    COUNT(p.PaymentID) as PaymentCount,
    ROUND(COUNT(p.PaymentID) * 100.0 / SUM(COUNT(p.PaymentID)) OVER (), 2) as Percentage,
    SUM(p.Amount) as TotalRevenue
FROM 
    Fact_Payment p
JOIN 
    Dim_PaymentMethod pm ON p.PaymentMethodID = pm.PaymentMethodID
GROUP BY 
    pm.MethodName
ORDER BY 
    TotalRevenue DESC
"""

# Truy vấn top khách hàng
top_customer_query = """
SELECT TOP 10
    c.FullName,
    ROUND(SUM(p.Amount), 2) as TotalRevenue
FROM 
    Fact_Payment p
JOIN 
    Dim_Booking b ON p.BookingID = b.BookingID
JOIN 
    Dim_Customer c ON b.CustomerID = c.CustomerID
GROUP BY 
    c.FullName
ORDER BY 
    TotalRevenue DESC
"""

# Đọc dữ liệu
df_payment_methods = run_query(payment_method_query)
df_top_customers = run_query(top_customer_query)

# Tạo layout 2 cột
col1, col2 = st.columns(2)

# Phân tích phương thức thanh toán
with col1:
    st.subheader("Phân bổ phương thức thanh toán")
    
    # Vẽ biểu đồ tròn
    fig1, ax1 = plt.subplots(figsize=(8, 8))
    ax1.pie(
        df_payment_methods['Percentage'], 
        labels=df_payment_methods['MethodName'], 
        autopct='%1.1f%%',
        colors=sns.color_palette('pastel'),
        startangle=90
    )
    ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
    
    st.pyplot(fig1)
    
    # Hiển thị bảng dữ liệu
    st.subheader("Chi tiết phương thức thanh toán")
    
    # Định dạng lại DataFrame để hiển thị
    display_df = df_payment_methods.copy()
    display_df.columns = ['Phương thức thanh toán', 'Số lượng giao dịch', 'Tỷ lệ (%)', 'Tổng doanh thu']
    
    st.dataframe(
        display_df.style.format({
            'Tổng doanh thu': '{:,.0f} VND',
            'Tỷ lệ (%)': '{:.2f}%'
        }),
        use_container_width=True
    )

# Phân tích top khách hàng
with col2:
    st.subheader("Top 10 khách hàng theo doanh thu")
    
    # Vẽ biểu đồ cột
    fig2, ax2 = plt.subplots(figsize=(10, 8))
    bars = sns.barplot(
        x='TotalRevenue', 
        y='FullName', 
        data=df_top_customers,
        palette='viridis',
        ax=ax2
    )
    
    ax2.set_xlabel('Tổng doanh thu (VND)', fontsize=12)
    ax2.set_ylabel('Khách hàng', fontsize=12)
    ax2.grid(True, linestyle='--', alpha=0.7, axis='x')
    
    # Thêm giá trị vào các cột
    for i, v in enumerate(df_top_customers['TotalRevenue']):
        ax2.text(v + v*0.01, i, f'{v:,.0f}', va='center')
    
    st.pyplot(fig2)
    
    # Hiển thị bảng dữ liệu
    st.subheader("Chi tiết top khách hàng")
    
    # Định dạng lại DataFrame để hiển thị
    display_df = df_top_customers.copy()
    display_df.columns = ['Tên khách hàng', 'Tổng chi tiêu']
    
    st.dataframe(
        display_df.style.format({
            'Tổng chi tiêu': '{:,.0f} VND'
        }),
        use_container_width=True
    )

# Phân tích bổ sung: Phân bổ doanh thu theo phương thức thanh toán
st.markdown("---")
st.subheader("Phân bổ doanh thu theo phương thức thanh toán")

# Vẽ biểu đồ cột
fig3, ax3 = plt.subplots(figsize=(12, 6))
bars = sns.barplot(
    x='MethodName', 
    y='TotalRevenue', 
    data=df_payment_methods,
    palette='viridis',
    ax=ax3
)

ax3.set_xlabel('Phương thức thanh toán', fontsize=12)
ax3.set_ylabel('Tổng doanh thu (VND)', fontsize=12)
ax3.set_title('Doanh thu theo phương thức thanh toán', fontsize=14)
ax3.grid(True, linestyle='--', alpha=0.7, axis='y')

# Thêm giá trị vào các cột
for i, v in enumerate(df_payment_methods['TotalRevenue']):
    ax3.text(i, v + v*0.01, f'{v:,.0f}', ha='center')

plt.xticks(rotation=45)
st.pyplot(fig3)
