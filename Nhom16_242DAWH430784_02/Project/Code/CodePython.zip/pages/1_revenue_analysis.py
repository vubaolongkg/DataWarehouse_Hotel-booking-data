import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as ticker  # Thêm import này ở đầu file
from datetime import datetime, timedelta
import numpy as np
from utils.database import run_query

# Thiết lập trang
st.set_page_config(
    page_title="Phân tích Doanh thu",
    page_icon="📈",
    layout="wide"
)

# Tiêu đề trang
st.title("📈 Phân tích Doanh thu chi tiết")
st.markdown("---")

# Truy vấn dữ liệu chi tiết (sử dụng các cột có trong bảng Dim_Date)
query = """
SELECT 
    d.DateKey,
    d.FullDate,
    d.DayName,
    d.Month, 
    d.MonthName,
    d.Year, 
    SUM(p.Amount) as TotalRevenue
FROM 
    Fact_Payment p
JOIN 
    Dim_Date d ON p.PaymentDateKey = d.DateKey
GROUP BY 
    d.DateKey,
    d.FullDate,
    d.DayName,
    d.Month, 
    d.MonthName,
    d.Year
ORDER BY 
    d.Year, 
    d.Month,
    d.FullDate
"""

df_revenue = run_query(query)

# Chuyển đổi cột FullDate thành datetime nếu cần
df_revenue['FullDate'] = pd.to_datetime(df_revenue['FullDate'])

# Trích xuất ngày từ FullDate nếu cần phân tích theo ngày
df_revenue['Day'] = df_revenue['FullDate'].dt.day

# Tạo các tùy chọn phân tích
st.sidebar.header("Tùy chọn phân tích")

# Chọn loại phân tích
analysis_type = st.sidebar.selectbox(
    "Chọn loại phân tích",
    ["Theo năm", "Theo tháng", "Theo ngày"]
)

# Lấy danh sách các năm có trong dữ liệu
years = sorted(df_revenue['Year'].unique())

# Tùy chọn dựa trên loại phân tích
if analysis_type == "Theo năm":
    selected_years = st.sidebar.multiselect(
        "Chọn năm để hiển thị",
        options=years,
        default=years
    )
    
    if not selected_years:
        st.warning("Vui lòng chọn ít nhất một năm để hiển thị dữ liệu.")
        st.stop()
    
    # Lọc dữ liệu theo năm đã chọn
    filtered_df = df_revenue[df_revenue['Year'].isin(selected_years)]
    
    # Tổng hợp dữ liệu theo tháng và năm
    monthly_data = filtered_df.groupby(['Year', 'Month', 'MonthName'])['TotalRevenue'].sum().reset_index()
    
    # Hiển thị biểu đồ
    st.subheader("Biểu đồ doanh thu theo tháng và năm")
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Tạo danh sách tháng theo thứ tự
    month_order = ['January', 'February', 'March', 'April', 'May', 'June', 
                  'July', 'August', 'September', 'October', 'November', 'December']
    
    # Đảm bảo có đủ 12 tháng cho mỗi năm (thêm giá trị 0 cho tháng thiếu dữ liệu)
    complete_data = []
    for year in selected_years:
        year_data = monthly_data[monthly_data['Year'] == year]
        for month_num, month_name in enumerate(month_order, 1):
            month_exists = ((year_data['Month'] == month_num) & (year_data['MonthName'] == month_name)).any()
            if month_exists:
                month_revenue = year_data.loc[(year_data['Month'] == month_num) & 
                                             (year_data['MonthName'] == month_name), 'TotalRevenue'].values[0]
            else:
                month_revenue = 0
            
            complete_data.append({
                'Year': year,
                'Month': month_num,
                'MonthName': month_name,
                'TotalRevenue': month_revenue
            })
    
    # Tạo DataFrame mới với dữ liệu đầy đủ
    complete_df = pd.DataFrame(complete_data)
    
    # Vẽ biểu đồ cho từng năm với dữ liệu đầy đủ
    for year in selected_years:
        year_data = complete_df[complete_df['Year'] == year]
        year_data = year_data.sort_values('Month')  # Sắp xếp theo tháng
        ax.plot(year_data['MonthName'], year_data['TotalRevenue'], 
                marker='o', linewidth=2, label=str(year))
    
    # Thêm đường xu hướng tổng thể
    if len(selected_years) > 1:
        trend_data = complete_df.groupby('Month')['TotalRevenue'].mean().reset_index()
        trend_data = trend_data.sort_values('Month')
        month_names = [month_order[i-1] for i in trend_data['Month']]
        ax.plot(month_names, trend_data['TotalRevenue'], 
                linestyle='--', color='gray', linewidth=1.5, label='Xu hướng trung bình')
    
    ax.set_title('Doanh Thu Theo Tháng Và Năm', fontsize=16)
    ax.set_xlabel('Tháng', fontsize=12)
    ax.set_ylabel('Doanh Thu (VND)', fontsize=12)
    ax.legend(title='Năm')
    plt.xticks(rotation=45)
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # Định dạng số tiền trên trục y
    ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
    
    st.pyplot(fig)
    
    # Hiển thị bảng dữ liệu
    st.subheader("Bảng dữ liệu doanh thu theo tháng")
    
    # Pivot table để hiển thị doanh thu theo tháng và năm
    pivot_df = complete_df.pivot(index='MonthName', columns='Year', values='TotalRevenue')
    
    # Sắp xếp các tháng theo thứ tự đúng
    pivot_df = pivot_df.reindex(month_order)
    
    # Hiển thị bảng pivot
    st.dataframe(pivot_df.style.format('{:,.0f} VND'), use_container_width=True)
    
    # Tính tổng doanh thu cho mỗi năm
    yearly_revenue = filtered_df.groupby('Year')['TotalRevenue'].sum().reset_index()
    yearly_revenue.columns = ['Năm', 'Tổng Doanh Thu']
    
    # Hiển thị tổng doanh thu theo năm
    st.subheader("Tổng doanh thu theo năm")
    
    # Biểu đồ cột cho tổng doanh thu theo năm
    fig2, ax2 = plt.subplots(figsize=(10, 5))
    bars = ax2.bar(yearly_revenue['Năm'].astype(str), yearly_revenue['Tổng Doanh Thu'], color='skyblue')
    
    # Thêm giá trị lên đầu mỗi cột
    for bar in bars:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                f'{height:,.0f}',
                ha='center', va='bottom', rotation=0)
    
    ax2.set_title('Tổng Doanh Thu Theo Năm', fontsize=16)
    ax2.set_xlabel('Năm', fontsize=12)
    ax2.set_ylabel('Tổng Doanh Thu (VND)', fontsize=12)
    ax2.grid(True, linestyle='--', alpha=0.7, axis='y')
    ax2.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
    
    st.pyplot(fig2)
    
    # Hiển thị bảng dữ liệu
    st.dataframe(yearly_revenue.style.format({'Tổng Doanh Thu': '{:,.0f} VND'}), use_container_width=True)

elif analysis_type == "Theo tháng":
    # Chọn năm trước
    selected_year = st.sidebar.selectbox(
        "Chọn năm",
        options=years,
        index=len(years)-1  # Mặc định chọn năm gần nhất
    )
    
    # Lọc dữ liệu theo năm đã chọn
    year_data = df_revenue[df_revenue['Year'] == selected_year]
    
    # Lấy danh sách các tháng có trong dữ liệu của năm đã chọn
    available_months = sorted(year_data['Month'].unique())
    
    # Chọn tháng
    selected_months = st.sidebar.multiselect(
        "Chọn tháng để hiển thị",
        options=available_months,
        default=available_months
    )
    
    if not selected_months:
        st.warning("Vui lòng chọn ít nhất một tháng để hiển thị dữ liệu.")
        st.stop()
    
    # Lọc dữ liệu theo tháng đã chọn
    filtered_df = year_data[year_data['Month'].isin(selected_months)]
    
    # Tổng hợp dữ liệu theo ngày
    daily_data = filtered_df.groupby(['Month', 'MonthName', 'Day', 'FullDate'])['TotalRevenue'].sum().reset_index()
    
    # Hiển thị biểu đồ
    st.subheader(f"Biểu đồ doanh thu theo ngày trong năm {selected_year}")
    
    fig, ax = plt.subplots(figsize=(15, 6))
    
    # Vẽ biểu đồ cho từng tháng
    for month in selected_months:
        month_data = daily_data[daily_data['Month'] == month]
        month_name = month_data['MonthName'].iloc[0] if not month_data.empty else f"Tháng {month}"
        
        ax.plot(month_data['FullDate'], month_data['TotalRevenue'], 
                marker='o', linewidth=2, label=f"Tháng {month} ({month_name})")
    
    ax.set_title(f'Doanh Thu Theo Ngày Trong Năm {selected_year}', fontsize=16)
    ax.set_xlabel('Ngày', fontsize=12)
    ax.set_ylabel('Doanh Thu (VND)', fontsize=12)
    ax.legend(title='Tháng')
    
    # Định dạng trục x để hiển thị ngày tháng
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d/%m'))
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=5))  # Hiển thị mốc mỗi 5 ngày
    plt.xticks(rotation=45)
    
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # Định dạng số tiền trên trục y
    ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
    
    st.pyplot(fig)
    
    # Hiển thị bảng dữ liệu
    st.subheader(f"Bảng dữ liệu doanh thu theo ngày trong năm {selected_year}")
    
    # Hiển thị dữ liệu theo ngày
    display_df = daily_data.copy()
    display_df['Ngày'] = display_df['FullDate'].dt.strftime('%d/%m/%Y')
    display_df = display_df[['Ngày', 'MonthName', 'TotalRevenue']]
    display_df.columns = ['Ngày', 'Tháng', 'Doanh thu']
    
    st.dataframe(display_df.style.format({'Doanh thu': '{:,.0f} VND'}), use_container_width=True)
    
    # Tính tổng doanh thu cho mỗi tháng
    monthly_revenue = filtered_df.groupby(['Month', 'MonthName'])['TotalRevenue'].sum().reset_index()
    monthly_revenue = monthly_revenue.sort_values('Month')
    monthly_revenue.columns = ['Tháng (số)', 'Tháng', 'Tổng Doanh Thu']
    
    # Hiển thị tổng doanh thu theo tháng
    st.subheader(f"Tổng doanh thu theo tháng trong năm {selected_year}")
    
    # Biểu đồ cột cho tổng doanh thu theo tháng
    fig2, ax2 = plt.subplots(figsize=(12, 5))
    bars = ax2.bar(monthly_revenue['Tháng'], monthly_revenue['Tổng Doanh Thu'], color='lightgreen')
    
    # Thêm giá trị lên đầu mỗi cột
    for bar in bars:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                f'{height:,.0f}',
                ha='center', va='bottom', rotation=0)
    
    ax2.set_title(f'Tổng Doanh Thu Theo Tháng Trong Năm {selected_year}', fontsize=16)
    ax2.set_xlabel('Tháng', fontsize=12)
    ax2.set_ylabel('Tổng Doanh Thu (VND)', fontsize=12)
    ax2.grid(True, linestyle='--', alpha=0.7, axis='y')
    ax2.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
    plt.xticks(rotation=45)
    
    st.pyplot(fig2)
    
    # Hiển thị bảng dữ liệu
    st.dataframe(monthly_revenue.style.format({'Tổng Doanh Thu': '{:,.0f} VND'}), use_container_width=True)

else:  # Theo ngày
    # Chọn khoảng thời gian
    col1, col2 = st.sidebar.columns(2)
    
    # Lấy ngày bắt đầu và kết thúc từ dữ liệu
    min_date = df_revenue['FullDate'].min().date()
    max_date = df_revenue['FullDate'].max().date()
    
    # Mặc định hiển thị dữ liệu của 30 ngày gần nhất
    default_start_date = max_date - timedelta(days=30)
    
    with col1:
        start_date = st.date_input(
            "Từ ngày",
            value=default_start_date,
            min_value=min_date,
            max_value=max_date
        )
    
    with col2:
        end_date = st.date_input(
            "Đến ngày",
            value=max_date,
            min_value=min_date,
            max_value=max_date
        )
    
    # Kiểm tra ngày bắt đầu và kết thúc
    if start_date > end_date:
        st.error("Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.")
        st.stop()
    
    # Lọc dữ liệu theo khoảng thời gian đã chọn
    mask = (df_revenue['FullDate'].dt.date >= start_date) & (df_revenue['FullDate'].dt.date <= end_date)
    filtered_df = df_revenue.loc[mask]
    
    if filtered_df.empty:
        st.warning("Không có dữ liệu trong khoảng thời gian đã chọn.")
        st.stop()
    
    # Tổng hợp dữ liệu theo ngày
    daily_data = filtered_df.groupby(['FullDate'])['TotalRevenue'].sum().reset_index()
    
    # Hiển thị biểu đồ
    st.subheader(f"Biểu đồ doanh thu theo ngày từ {start_date.strftime('%d/%m/%Y')} đến {end_date.strftime('%d/%m/%Y')}")
    
    fig, ax = plt.subplots(figsize=(15, 6))
    
    # Vẽ biểu đồ doanh thu theo ngày
    ax.plot(daily_data['FullDate'], daily_data['TotalRevenue'], 
            marker='o', linewidth=2, color='blue')
    
    # Thêm đường xu hướng
    z = np.polyfit(range(len(daily_data)), daily_data['TotalRevenue'], 1)
    p = np.poly1d(z)
    ax.plot(daily_data['FullDate'], p(range(len(daily_data))), 
            linestyle='--', color='red', linewidth=1.5, label='Xu hướng')
    
    ax.set_title('Doanh Thu Theo Ngày', fontsize=16)
    ax.set_xlabel('Ngày', fontsize=12)
    ax.set_ylabel('Doanh Thu (VND)', fontsize=12)
    ax.legend()
    
    # Định dạng trục x để hiển thị ngày tháng
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d/%m/%Y'))
    
    # Điều chỉnh số lượng mốc trên trục x dựa vào số ngày
    days_count = (end_date - start_date).days + 1
    interval = max(1, days_count // 10)  # Hiển thị tối đa khoảng 10 mốc
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=interval))
    
    plt.xticks(rotation=45)
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # Định dạng số tiền trên trục y
    ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
    
    st.pyplot(fig)
    
    # Hiển thị bảng dữ liệu
    st.subheader("Bảng dữ liệu doanh thu theo ngày")
    
    # Hiển thị dữ liệu theo ngày
    display_df = daily_data.copy()
    display_df['Ngày'] = display_df['FullDate'].dt.strftime('%d/%m/%Y')
    display_df = display_df[['Ngày', 'TotalRevenue']]
    display_df.columns = ['Ngày', 'Doanh thu']
    
    st.dataframe(display_df.style.format({'Doanh thu': '{:,.0f} VND'}), use_container_width=True)
    
    # Tính toán thống kê
    total_revenue = daily_data['TotalRevenue'].sum()
    avg_revenue = daily_data['TotalRevenue'].mean()
    max_revenue = daily_data['TotalRevenue'].max()
    max_date = daily_data.loc[daily_data['TotalRevenue'].idxmax(), 'FullDate'].strftime('%d/%m/%Y')
    min_revenue = daily_data['TotalRevenue'].min()
    min_date = daily_data.loc[daily_data['TotalRevenue'].idxmin(), 'FullDate'].strftime('%d/%m/%Y')
    
    # Hiển thị thống kê
    st.subheader("Thống kê doanh thu")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Tổng doanh thu", f"{total_revenue:,.0f} VND")
        st.metric("Doanh thu trung bình/ngày", f"{avg_revenue:,.0f} VND")
    
    with col2:
        st.metric("Doanh thu cao nhất", f"{max_revenue:,.0f} VND")
        st.metric("Ngày có doanh thu cao nhất", max_date)
    
    with col3:
        st.metric("Doanh thu thấp nhất", f"{min_revenue:,.0f} VND")
        st.metric("Ngày có doanh thu thấp nhất", min_date)
