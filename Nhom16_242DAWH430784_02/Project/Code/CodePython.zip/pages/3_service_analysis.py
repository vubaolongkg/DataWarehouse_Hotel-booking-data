import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from utils.database import run_query

# Thiết lập trang
st.set_page_config(
    page_title="Phân tích Dịch vụ",
    page_icon="🛎️",
    layout="wide"
)

# Tiêu đề trang
st.title("🛎️ Phân tích Doanh thu Dịch vụ")
st.markdown("---")

# Truy vấn chi tiết doanh thu dịch vụ
query_service_revenue = """
WITH ServiceRevenue AS (
    SELECT 
        s.ServiceName,
        SUM(fs.Quantity * s.Price) as TotalRevenue,
        SUM(fs.Quantity) as TotalQuantity
    FROM 
        Fact_ServiceUsage fs
    JOIN 
        Dim_Service s ON fs.ServiceID = s.ServiceID
    GROUP BY 
        s.ServiceName
)
SELECT 
    ServiceName,
    TotalRevenue,
    TotalQuantity,
    ROUND(TotalRevenue * 100.0 / SUM(TotalRevenue) OVER (), 2) as RevenuePercentage
FROM 
    ServiceRevenue
ORDER BY 
    TotalRevenue DESC
"""

# Đọc dữ liệu
df_service_revenue = run_query(query_service_revenue)

# Biểu đồ tròn phân bổ doanh thu
st.subheader("Phân bổ doanh thu theo dịch vụ")

fig1, ax1 = plt.subplots(figsize=(10, 10))
ax1.pie(
    df_service_revenue['TotalRevenue'], 
    labels=df_service_revenue['ServiceName'], 
    autopct='%1.1f%%',
    colors=sns.color_palette('pastel'),
    startangle=90
)
ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle

st.pyplot(fig1)

# Biểu đồ cột doanh thu dịch vụ
st.subheader("Doanh thu chi tiết từng dịch vụ")

fig2, ax2 = plt.subplots(figsize=(12, 6))
bars = sns.barplot(
    x='ServiceName', 
    y='TotalRevenue', 
    data=df_service_revenue,
    palette='viridis',
    ax=ax2
)

ax2.set_xlabel('Tên dịch vụ', fontsize=12)
ax2.set_ylabel('Tổng doanh thu (VND)', fontsize=12)
ax2.set_title('Doanh thu theo dịch vụ', fontsize=14)
ax2.grid(True, linestyle='--', alpha=0.7, axis='y')

# Thêm giá trị vào các cột
for i, v in enumerate(df_service_revenue['TotalRevenue']):
    ax2.text(i, v + v*0.01, f'{v:,.0f}', ha='center')

plt.xticks(rotation=45)
st.pyplot(fig2)

# Hiển thị bảng dữ liệu
st.subheader("Chi tiết doanh thu dịch vụ")

# Định dạng lại DataFrame để hiển thị
display_df = df_service_revenue.copy()
display_df.columns = ['Tên dịch vụ', 'Tổng doanh thu', 'Số lượng sử dụng', 'Tỷ lệ doanh thu (%)']

st.dataframe(
    display_df.style.format({
        'Tổng doanh thu': '{:,.0f} VND',
        'Tỷ lệ doanh thu (%)': '{:.2f}%'
    }),
    use_container_width=True
)

# Biểu đồ số lượng sử dụng dịch vụ
st.subheader("Số lượng sử dụng dịch vụ")

fig3, ax3 = plt.subplots(figsize=(12, 6))
bars = sns.barplot(
    x='ServiceName', 
    y='TotalQuantity', 
    data=df_service_revenue,
    palette='muted',
    ax=ax3
)

ax3.set_xlabel('Tên dịch vụ', fontsize=12)
ax3.set_ylabel('Số lượng sử dụng', fontsize=12)
ax3.set_title('Số lượng sử dụng theo dịch vụ', fontsize=14)
ax3.grid(True, linestyle='--', alpha=0.7, axis='y')

# Thêm giá trị vào các cột
for i, v in enumerate(df_service_revenue['TotalQuantity']):
    ax3.text(i, v + v*0.01, f'{v:,.0f}', ha='center')

plt.xticks(rotation=45)
st.pyplot(fig3)

# Phân tích mối quan hệ giữa số lượng và doanh thu
st.subheader("Mối quan hệ giữa số lượng sử dụng và doanh thu")

fig4, ax4 = plt.subplots(figsize=(10, 8))
sns.scatterplot(
    x='TotalQuantity', 
    y='TotalRevenue',
    size='RevenuePercentage',
    hue='ServiceName',
    data=df_service_revenue,
    ax=ax4
)

for i, row in df_service_revenue.iterrows():
    ax4.text(row['TotalQuantity'], row['TotalRevenue'], row['ServiceName'])

ax4.set_xlabel('Số lượng sử dụng', fontsize=12)
ax4.set_ylabel('Tổng doanh thu (VND)', fontsize=12)
ax4.grid(True, linestyle='--', alpha=0.7)

st.pyplot(fig4)
